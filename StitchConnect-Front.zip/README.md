# React + Vite

This template provides React startup with Vite which includes Comeplte folder structuring , React Routing , Error Page Handling , React Toaster , Swiper and last but not the least Chakra Ui.
