export const imgURL = "/images/";
export const DOMIAN_URL = "http://localhost:3015/";
export const BASE_URL = "http://localhost:8000/";