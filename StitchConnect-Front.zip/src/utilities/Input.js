export const labelStyle = "font-normal text-sm text-black";
export const inputStyle =
  "w-full resize-none font-normal text-base text-black rounded py-2.5 px-4 bg-theme-gray-4 border-none placeholder:text-black placeholder:text-opacity-40 focus:outline-none";
